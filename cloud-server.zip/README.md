# AWS Basics Server

A basic Pokemon name querying service deployed to AWS.